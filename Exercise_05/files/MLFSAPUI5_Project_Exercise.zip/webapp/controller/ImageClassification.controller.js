sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	'sap/m/Dialog',
	"sap/suite/ui/microchart/RadialMicroChart",
	"sap/ui/core/routing/History"
], function(Controller, MessageToast, Dialog, RadialMicroChart, History) {
	"use strict";

	return Controller.extend("demo.MLFSAPUI5_Project.controller.ImageClassification", {
		
		onInit: function () {
	        this.mBindingOptions = {};
	        this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
	        this.oRouter.getTarget("ImageClassification").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
	        this.getView().byId("fileUploader").addStyleClass("fileUploaderStyle1");
        },

		handleTypeMissmatch: function(oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function(key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},

		handleValueChange: function(oEvent) {
			// keep a reference in the view to close it later
			var oBusyIndicator = new sap.m.BusyDialog();
			// start the busy indicator
			oBusyIndicator.open();

			var oView = this.getView();
			var settings = oView.getModel("settings");
			var urls = settings.getProperty("/urls");

			var reader = new FileReader();
			reader.onloadend = function() {
				var model = oView.getModel().getData();
				model.image = reader.result;
				oView.getModel().refresh();
				oView.byId("fileUploader").addStyleClass("fileUploaderStyle2");
				oView.byId("uploadBox").setJustifyContent(null);
				oView.byId("flexBoxHint").setVisible(false);
				oView.byId("uploadBox").addStyleClass("workListBox2");
				oView.byId("vBoxImage").setVisible(true);
			};
			
			this.setupModel(oView);
			var table = oView.byId("table");
			table.destroyColumns();
			
			if(oEvent.getParameters().files[0] !== undefined) {
				reader.readAsDataURL(oEvent.getParameters().files[0]);
	
				var cells = new Array(urls.length);
				for (var i = 0; i < urls.length; i++) {
					table.addColumn(new sap.m.Column({
	
						header: new sap.m.FlexBox({
							alignItems: "Center",
							justifyContent: "Center",
							items: [
								new sap.m.VBox({
									items: [
										new sap.m.Label({
											textAlign: "Center",
											width: "100%",
											text: urls[i].name
										}),
										new sap.m.FlexBox({
											alignItems: "Center",
											justifyContent: "Center",
											items: [
												new sap.m.Button({
													textAlign: "Center",
													id: "json" + i,
													text: "View JSON",
													press: [this.viewJSON, this]
												})
											]
										})
									]
								})
							]
						})
	
					}));
					cells[i] = new sap.m.HBox({
					items: [
						new sap.m.VBox({
							width: "50%",
							items: [new sap.m.Label({
								text: "{label/" + i + "}",
								design: "Bold",
								class: "sapUiSmallMargin"
							})]
						}),

						new sap.m.VBox({
							width: "30%",
							items: [new RadialMicroChart({
								size: "L",
								percentage: "{score/" + i + "}",
								class: "sapUiSmallMargin"
							})]
						})
					]
				});
				
				this.callAPI(i, urls[i], oEvent.getParameters().files[0], oView, oBusyIndicator);
				
				}
				table.bindItems("/results", new sap.m.ColumnListItem({
					cells: cells
				}));
				table.setVisible(true);
			
			} else {
				oBusyIndicator.close();
				table.setVisible(false);
				oView.byId("fileUploader").removeStyleClass("fileUploaderStyle2");
				oView.byId("uploadBox").setJustifyContent("Center");
				oView.byId("flexBoxHint").setVisible(true);
				oView.byId("flexBoxHint").addStyleClass("hintFlexBox");
				oView.byId("uploadBox").removeStyleClass("workListBox2");
				oView.byId("vBoxImage").setVisible(false);
			}
		},

		callAPI: function(i, url, file, oView, oBusyIndicator) {
			var form = new FormData();
			form.append("files", file);
			if (!(typeof url.options === "undefined")) {
				form.append("options", JSON.stringify(url.options));
			}
			$.ajax({
				url: url.url,
				type: "POST",
				headers: url.headers,
				data: form,
				processData: false,
				contentType: false,
				success: function(data) {
					try {
						var model = oView.getModel().getData();
						model["json" + i] = JSON.stringify(data, null, "\t");
						for (var j = 0; j < model.results.length; j++) {
							if (data.predictions[0].results[j].score > 0.01) {
								model.results[j].score[i] = Math.round(data.predictions[0].results[j].score * 1000) / 10;
							} else {
								model.results[j].score[i] = Math.round(data.predictions[0].results[j].score * 100000) / 1000;
							}

							var l = data.predictions[0].results[j].label;
							model.results[j].label[i] = ((l[0] + "").toUpperCase()) + l.substring(1, l.length);
						}
						oView.getModel().refresh();
						oBusyIndicator.close();
					} catch (err) {
						oBusyIndicator.close();
						//displays error message
						MessageToast.show("Caught - [ajax error] :" + err.message);
					}
				},
				error: function(request, status, error) {
					oBusyIndicator.close();
					//displays error message
					MessageToast.show("Caught - [ajax error] :" + request.responseText);
				}
			});
		},

		draggableDialog: null,

		viewJSON: function(oEvent) {
			var id = oEvent.getSource().getId();
			this.draggableDialog = new Dialog({
				title: 'JSON Preview',
				ontentWidth: "90vw",
				draggable: true,
				resizable: true,
				content: new sap.ui.core.HTML({
					content: "<html><body><pre><code>{/" + id + "}</code></pre></body></html>"
				}),
				beginButton: new sap.m.Button({
					text: 'Close',
					press: function() {
						this.draggableDialog.close();
					}.bind(this)
				})
			});

			//to get access to the global model
			this.getView().addDependent(this.draggableDialog);

			this.draggableDialog.open();
		},

		setupModel: function(oView) {
			var m = {};
			m.results = [];
			for (var i = 0; i < 5; i++) {
				m.results[i] = {};
				m.results[i].score = [""];
				m.results[i].label = [""];
			}

			oView.setModel(new sap.ui.model.json.JSONModel(m));
		},
		
		//navigation functions
		
		handleRouteMatched: function (oEvent) {
			var oParams = {}; 
			
			if (oEvent.mParameters.data.context) { 
			    this.sContext = oEvent.mParameters.data.context;
			    var oPath; 
			    if (this.sContext) { 
			        oPath = {path: "/" + this.sContext, parameters: oParams}; 
			        this.getView().bindObject(oPath);
			    } 
			}
        },
        
		_onPageNavButtonPress: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			var oQueryParams = this.getQueryParameters(window.location);
			
			if (sPreviousHash !== undefined || oQueryParams.navBackToLaunchpad) {
			    window.history.go(-1);
			} else {
			    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.navTo("default", true);
			}
			
			//hide the error message when navigating back
			this.getView().byId("flexBoxHint").setVisible(false);
        },
        
		getQueryParameters: function (oLocation) {
			var oQuery = {};
			var aParams = oLocation.search.substring(1).split("&");
			for (var i = 0; i < aParams.length; i++) {
			    var aPair = aParams[i].split("=");
			    oQuery[aPair[0]] = decodeURIComponent(aPair[1]);
			}
			return oQuery;
		
        },
		
		_onNavToTokenGen: function(oEvent) {
			this.oRouter.navTo("Token");
			
			//hide the error message when navigating back
			this.getView().byId("flexBoxHint").setVisible(false);
		}
	});
});