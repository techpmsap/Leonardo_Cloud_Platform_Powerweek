sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'jquery.sap.global',
	'sap/m/MessageToast',
	'sap/ui/core/routing/History'
], function(Controller, jQuery, MessageToast, History) {
	"use strict";

	var image = null;

	return Controller.extend("demo.MLFSAPUI5_Project.controller.Byom", {
		
		onInit: function () {
			this.mBindingOptions = {};
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("Byom").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			
			sap.ui.getCore().attachValidationError(function (evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			
			sap.ui.getCore().attachValidationSuccess(function (evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
		},
		
		handleContinue : function (evt) {
			var view = this.getView();
			var inputs = [
				view.byId("inf_url")
			];
			jQuery.each(inputs, function (i, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
				} else {
					input.setValueState("None");
				}
			});
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
				if ("Error" === input.getValueState()) {
					canContinue = false;
					return false;
				}
			});

			if (canContinue) {
				this.generateRequest();
			} else {
				jQuery.sap.require("sap.m.MessageBox");
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"Every field needs to be filled!",
					{
						styleClass: bCompact? "sapUiSizeCompact" : "",
						actions: sap.m.MessageBox.Action.CLOSE
					}
				);
			}
		},
		
		handleTypeMissmatch: function(oEvent) {
			var fileType = oEvent.getSource().getFileType();
			jQuery.each(fileType, function(key, value) {
				fileType[key] = "*." +  value;
			});
			var supportedFileTypes = fileType.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
									" is not supported. Choose one of the following types: " +
									supportedFileTypes);
		},
		
		uploadImage: function(oEvent) {
			$('.loader').hide();
			$('.byomImagePreview').attr('src', "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAQAAADa613fAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QA/4ePzL8AAAAHdElNRQfiARMHCBOhvBy7AAAEKElEQVR42u3bTWgUZxzH8e9MNobs+kJq1INEosTXoCjBBqUGYqnkZGkptKjxIPZUEDyoFyEHT4qXQlHwBZGWUMFWJAd7qYheSrC1VcRYUeKqCQHTKqSSXeOOhyX6zGb3meeZme0zs8zvOc3s5tn/J7Mz88zMs5AkSZIkSZIkqZ1YrqUMzWSwTRelEIdJxnmJMxPSypf0sJR0CS6qyTHKDfr5g8L7lTafcYcCTuzaKIfIvIf08tx4SX5bnuM0Fhkf8cx4OUHaJN8AZPjZeClB29+sqaOLg9ObJrZpYjzFFpqEVY/4hf9M16WQOjbT+e74arMVvhc20QTbTVeonDaGhMqztutr9YK7putTzhOGhaWG0rO4o9GV2TjuWuMwHFFKzUBSGu+1qCdFgbw4uolK1CAWLXSziVbS5BjhJlcZ4o3p4nUhTezha9qoe7eml1F+5FuypssXc1E4Gj9l2YzXW/mJqbIDg9/oNFj3LK4ItYx57eyLOcnnwrYQ08lZOgxSXJFDGjhMj+T1do6x0DRBBfIxOz3+vpvdpgnekHp6mePx9xY7orFNZJAWNin0sIp1phFekFal/3Uj7YEqaA/ngCGDLKBBqY9FAT5/HefpZ0t1IbbijaE6pXeVZ5yhgxWcDk6RQV7wWqmPfwIwNgKwMjhFBnnMvwo9vOZ+QEYoFBlkmNsKPWT5MzAjBIoM8ooLTHn2MMDjEBghUGSDxibXwKxcu8cqH4zBiv0NKVNKBo1eo98O7kkYz/kiVIYORRMCXdyp8JGj7Na+VPZiqFO0IbCGfiZKPizHVbq1H0CoMFQpPiDQyDZOMEiWMZ7xFz/wlev+ZLgMNYovCIDNPJaymjaafZ3LdRgqFN+QYNFleFM0L3XDYpQ7b3hF67zyf0D8MTQp1Yf4Z2hRqg0JxtCgBIHMpqXqDGWKf0iaPi7xYdUZyhR/h980R8njcLsixc8BV+dgHMp5ZJrhVKSEzShSNocLERnlKdVgODh8Vxmiv4+k6WM/9cKatZxxUcLbN0ojeXagC5nJKKVUjyGNHqQ8Q6QYYuhBKjOKlFPs4pQZhs4zRDkDiltjlhmGOsSbAZbiLdaqRO2rpcIwHBVIDBgqkFgwvCExYXhBYsOQQ2LEkEM+YV9cGHLIXJPnhTAh8ZmERg3N10ogUUsCiVpqBiK7HimQN12eK/WyWZQyyDW2R+rXPZZsDqUMMsKI6drVUzP7SAKJWmzXkaDBcw5jdOKu9U2KMWGxmQOcZNJ0jQqx6WGDsDye4iY54bpjB59Ga857hVhkXE/7f7dYwkA05okGyEt22WQ5rTArK9q5zK8AczgXy5+3TrdBlk+LFnCWnPGC/LQC11kvbpwMexnklfHCdFqeBxxhcREgDgrns57VfIBN1G87WDhM8JBbPIniz6SSJEmSJEkSY3kLmZYha0cteJIAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTgtMDEtMTlUMDc6MDg6MTktMDU6MDCYFCzEAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE4LTAxLTE5VDA3OjA4OjE5LTA1OjAw6UmUeAAAAABJRU5ErkJggg==");
			$('.errorTxt').text("An error occured while trying to scan the handwritten digit! Please check your input image. If this error keeps occuring please check back with a trainer.").hide();
			this.hideInfoMessages();
			
			if(this.getView().byId("imageUpload").oFileUpload.files && this.getView().byId("imageUpload").oFileUpload.files[0]) {
				var fileReader = new FileReader();
				fileReader.onload = function (res) {
	                image = res.target.result;
	                $('.byomImagePreview')
	                    .attr('src', res.target.result)
	                    .width(100)
	                    .height(100);
	            };
	            fileReader.readAsDataURL(this.getView().byId("imageUpload").oFileUpload.files[0]);
			}
		},
		
		handleFileSizeExceed: function(oEvent) {
			$('.errorTitle').hide();
			$('.errorTxt').hide();
			$('.loader').hide();
			
			image = null;
			
			this.displayErrorMessage("File size exceeded! The maximum file size is 784KB. Please select another image!");
		},
		
		uploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("response");
		    if (sResponse) {
		        console.log(sResponse);
		    }
		},
		
		generateRequest: function(oEvent) {
			if(!this.getView().byId("imageUpload").oFileUpload.files[0]) {
				this.displayErrorMessage("Choose an image first!");
				return;
			}
			
			this.hideInfoMessages();
			
			var data = new FormData();
			data.append("file", this.getView().byId("imageUpload").oFileUpload.files[0]);
			
			$.ajax({
				"async": true,
				"url": this.getView().byId("inf_url").getValue(),
				//"url": "https://mnist.cfapps.eu10.hana.ondemand.com",
				"method": "POST",
				"headers": {
					"Cache-Control": "no-cache",
					"Postman-Token": "da88cd85-7123-8371-28e4-011f82cf6826"
				},
				"processData": false,
				"contentType": false,
				"mimeType": "multipart/form-data",
				"data": data
			}).done(function (response) {
				
				$('.loader').hide();
				
				setTimeout(function() {
					$('.byomResultTitle').fadeIn().css("display","block");
					$('.byomResultTxt').text(response.slice(-1)).fadeIn().css("display","block");
				}, 400);
				
			}).fail(function (jqXHR, textStatus) {
				
				$('.loader').hide();
				
				setTimeout(function() {
					$('.errorTitle').fadeIn().css("display","block");
					$('.errorTxt').fadeIn().css("display","block");
				}, 400);
				
			});
		},
		
		displayErrorMessage: function(message) {
			setTimeout(function() {
				$('.errorTxt').text(message);
				$('.errorTitle').fadeIn().css("display","block");
				$('.errorTxt').fadeIn().css("display","block");
			}, 200);
		},
		
		hideInfoMessages: function() {
			$('.byomResultTxt').hide();
			$('.byomResultTitle').hide();
			$('.errorTitle').hide();
			$('.errorTxt').hide();
			$('.loader').hide();
		},
		
		//navigation functions

		handleRouteMatched: function (oEvent) {
			var oParams = {}; 
			
			if (oEvent.mParameters.data.context) { 
			    this.sContext = oEvent.mParameters.data.context;
			    var oPath; 
			    if (this.sContext) { 
			        oPath = {path: "/" + this.sContext, parameters: oParams}; 
			        this.getView().bindObject(oPath);
			    } 
			}
        },
        
		_onPageNavButtonPress: function () {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			var oQueryParams = this.getQueryParameters(window.location);
			
			if (sPreviousHash !== undefined || oQueryParams.navBackToLaunchpad) {
			    window.history.go(-1);
			} else {
			    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.navTo("default", true);
			}
			
			//hide the info messages when navigating back
			$('.errorTitle').hide();
			$('.errorTxt').hide();
		},
		
		getQueryParameters: function (oLocation) {
			var oQuery = {};
			var aParams = oLocation.search.substring(1).split("&");
			for (var i = 0; i < aParams.length; i++) {
			    var aPair = aParams[i].split("=");
			    oQuery[aPair[0]] = decodeURIComponent(aPair[1]);
			}
			return oQuery;
		},
		
		_onNavToTokenGen: function(oEvent) {
			this.oRouter.navTo("Token");
			
			//hide the info messages when navigating
			$('.errorTitle').hide();
			$('.errorTxt').hide();
		}
	});
});