sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	'sap/m/Dialog',
	'sap/m/MessageBox',
	"sap/ui/core/Fragment",
	"sap/ui/core/routing/History"
], function(Controller, MessageToast, MessageBox, Dialog, History, JSONModel) {
	"use strict";

	return Controller.extend("demo.MLFSAPUI5_Project.controller.Token", {
		
		onInit: function () {
			sap.ui.getCore().attachValidationError(function (evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function (evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
			
			this.mBindingOptions = {};
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("Token").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			
			setTimeout(this.readCookies, 300);
		},
		
		handleContinue : function () {
			var view = this.getView();
			var inputs = [
				view.byId("auth"),
				view.byId("id"),
				view.byId("secret")
			];
			jQuery.each(inputs, function (i, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
				} else {
					input.setValueState("None");
				}
			});
			var canContinue = true;
			jQuery.each(inputs, function (i, input) {
				if ("Error" === input.getValueState()) {
					canContinue = false;
					return false;
				}
			});

			if (canContinue) {
				this.generateRequest();
			} else {
				jQuery.sap.require("sap.m.MessageBox");
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.error(
					"Every field needs to be filled!",
					{
						styleClass: bCompact? "sapUiSizeCompact" : "",
						actions: sap.m.MessageBox.Action.CLOSE
					}
				);
			}
		},
		
		saveCookies : function () {
			var getParameterModel = this.getView().getModel("parameter");
			
			if ($('#__component0---Token--saveCookie').attr('aria-checked') === "true") {
				console.log("Saving data to Cookies ... Will expire in 3 days!");
				var expires = new Date();
				var currentDay = expires.getDate();
				expires.setDate(currentDay + 7);
				var saveCookies = true;
			} else {
				console.log("Deleting Cookies ...");
				var expires = new Date('December 31, 1990 00:00:00');
				getParameterModel.setData({
					authKey: "",
					clientId: "",
					clientSecret: "",
					saveCookies: false
				});
				var saveCookies = false;
			}
			document.cookie = "authKey=" + getParameterModel.getProperty("/authKey") + ";" + expires;
			document.cookie = "clientId=" + getParameterModel.getProperty("/clientId") + ";" + expires;
			document.cookie = "clientSecret=" + getParameterModel.getProperty("/clientSecret") + ";" + expires;
			document.cookie = "saveCookies=" + saveCookies + ";" + expires;
		},
		
		getCookie: function (cname) {
			var name = cname + "=";
		    var decodedCookie = decodeURIComponent(document.cookie);
		    var ca = decodedCookie.split(';');
		    for(var i = 0; i <ca.length; i++) {
		        var c = ca[i];
		        while (c.charAt(0) === ' ') {
		            c = c.substring(1);
		        }
		        if (c.indexOf(name) === 0) {
		            return c.substring(name.length, c.length);
		        }
		    }
		    return "";
		},
		
		readCookies: function (evt) {
			var getParameterModel = this.getView().getModel("parameter");

			getParameterModel.setData({
				authKey: this.getCookie("authKey"),
				clientId: this.getCookie("clientId"),
				clientSecret: this.getCookie("clientSecret"),
				saveCookies: this.getCookie("saveCookies")
			});
			
			if (this.getCookie("saveCookies") === "true") {
				$('#__component0---Token--saveCookie').attr('aria-checked', this.getCookie("saveCookies"));
				$('#__component0---Token--saveCookie-CbBg').addClass("sapMCbMarkChecked");
				$('#__component0---Token--saveCookie-CB').attr('checked', 'checked');
			}
		},
		
		copyToClipBoard : function () {
			var $temp = $("<input>");
			$("body").append($temp);
			console.log($('.errorTxt').text());
			$temp.val($('.errorTxt').text()).select();
			document.execCommand("copy");
			$temp.remove();
			sap.m.MessageToast.show("Copied Token!", {at: "center center"});
		},
		
		generateRequest : function () {
			var getParameterModel = this.getView().getModel("parameter");
			
			console.log(getParameterModel.getProperty("/authKey/"));
			console.log(getParameterModel.getProperty("/clientId/"));
			console.log(getParameterModel.getProperty("/clientSecret/"));
			
			$('.errorTxt').text("");
			$('.errorTitle').hide();
			$('.errorTxt').hide();
			$('.copyClipBoardBtn').hide();
			$('.loader').fadeIn();
			
			// var getAuth = {
			// 	"async": true,
			// 	"crossDomain": true,
			// 	"url": getParameterModel.getProperty("/authKey/") + "/oauth/token?grant_type=client_credentials",
			// 	"method": "GET",
			// 	"headers": {
			// 	    "Authorization": "Basic " + btoa(getParameterModel.getProperty("/clientId/") + ":" + getParameterModel.getProperty("/clientSecret/")),
			// 	    "Cache-Control": "no-cache"
			// 	  }
			// };
		
			$.ajax({
				"async": true,
				"crossDomain": true,
				//"url": "https://get_token.cfapps.eu10.hana.ondemand.com/gen_token",
				"url": "https://get_token_adapter.cfapps.eu10.hana.ondemand.com",
				"method": "GET",
				"headers": {
					"auth": getParameterModel.getProperty("/authKey/"),
					"id": getParameterModel.getProperty("/clientId/"),
					"secret": getParameterModel.getProperty("/clientSecret/"),
					"Cache-Control": "no-cache"
				}
			}).done(function (response) {
				$('.loader').hide();
				setTimeout(function() {
					$('.errorTxt').text("Bearer " + response);
					$('.errorTitle').text("Your Token:");
					$('.errorTitle').css("color", "#333333");
					$('.errorTitle').fadeIn().css("display","block");
					$('.errorTxt').fadeIn().css("display","block");
					$('.copyClipBoardBtn').fadeIn();
				}, 300);
			}).fail(function (jqXHR, textStatus) {
				$('.loader').hide();
				setTimeout(function() {
					$('.errorTxt').text("An Error occured while trying to generate token! Please double check your inputs. If this error keeps occuring please check back with a trainer.");
					$('.errorTitle').text("Error!");
					$('.errorTitle').css("color", "#C0392B");
					$('.errorTitle').fadeIn().css("display","block");
					$('.errorTxt').fadeIn().css("display","block");
				}, 300);
			});
			
			this.saveCookies();
		},
		
		//navigation functions
		
		handleRouteMatched: function (oEvent) {
			var oParams = {}; 
			
			if (oEvent.mParameters.data.context) { 
			    this.sContext = oEvent.mParameters.data.context;
			    var oPath; 
			    if (this.sContext) { 
			        oPath = {path: "/" + this.sContext, parameters: oParams}; 
			        this.getView().bindObject(oPath);
			    } 
			}
        },
        
		_onPageNavButtonPress: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			var oQueryParams = this.getQueryParameters(window.location);
			
			if (sPreviousHash !== undefined || oQueryParams.navBackToLaunchpad) {
			    window.history.go(-1);
			} else {
			    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.navTo("default", true);
			}
			
			//hide the info messages when navigating back
			$('.errorTitle').hide();
			$('.errorTxt').hide();
		},
		
		getQueryParameters: function (oLocation) {
			var oQuery = {};
			var aParams = oLocation.search.substring(1).split("&");
			for (var i = 0; i < aParams.length; i++) {
			    var aPair = aParams[i].split("=");
			    oQuery[aPair[0]] = decodeURIComponent(aPair[1]);
			}
			return oQuery;
		}
	});
});