from base64 import b64encode
import os
from grpc.beta import implementations
import tensorflow as tf
import skimage.io
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2
import json
import requests
from flask import Flask, globals
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

service = (json.loads(os.getenv('VCAP_SERVICES', '')))['ml-foundation'][0]

MODEL_NAME = str(os.getenv('MODEL_NAME', ''))
client_id = str(service['credentials']['clientid'])
client_secret = str(service['credentials']['clientsecret'])
authentication_url = str(service['credentials']['url']) + "/oauth/token"


def get_access_token():
    querystring = {"grant_type":"client_credentials"}
    auth = b64encode(b"" + client_id + ":" + client_secret).decode("ascii")
    headers = {
        'Cache-Control': "no-cache",
        'Authorization': "Basic %s" % auth
    }
    response = requests.request("GET", authentication_url, headers=headers, params=querystring)
    print(response)
    return 'Bearer ' + json.loads(response.text)['access_token']


def metadata_transformer(metadata):
    additions = []
    token = get_access_token()
    additions.append(('authorization', token))
    return tuple(metadata) + tuple(additions)


@app.route('/', methods=['POST'])
def main():
    deployment_url = str(service['credentials']['serviceurls']['DEPLOYMENT_API_URL']) + "/api/v1/deployments"
    querystring = {"modelName": MODEL_NAME}
    headers = {
        'Authorization': get_access_token(),
        'Cache-Control': "no-cache"
    }
    response = requests.request("GET", deployment_url, headers=headers, params=querystring)
    model_info = json.loads(response.text)

    credentials = implementations.ssl_channel_credentials(root_certificates=str(model_info["caCrt"]))
    model_info = model_info["content"][0]
    channel = implementations.secure_channel(str(model_info["modelContainer"]["host"]),
                                             int(model_info["modelContainer"]["port"]), credentials)
    stub = prediction_service_pb2.beta_create_PredictionService_stub(channel, metadata_transformer=metadata_transformer)

    uploaded_files = globals.request.files.getlist('file')
    data = skimage.io.imread(uploaded_files[0])

    request = predict_pb2.PredictRequest()
    request.model_spec.name = MODEL_NAME
    request.model_spec.signature_name = 'predict_images'
    request.inputs["images"].CopyFrom(
        tf.contrib.util.make_tensor_proto(data, shape=[1, data.size], dtype="float32"))
    res = str(stub.Predict(request, 150)).split('}')[3].split('\n')
    res.pop(11)
    res.pop(0)
    out_val = 0.0
    out = 0
    for i, estimate in enumerate(res):
        if float(estimate[14:]) > out_val:
            out_val = float(estimate[14:])
            out = i
    return "Result: " + str(out)


port = os.getenv('PORT', 5000)
if __name__ == '__main__':
    app.debug = not os.getenv('PORT')
    app.run(host='0.0.0.0', port=int(port))
